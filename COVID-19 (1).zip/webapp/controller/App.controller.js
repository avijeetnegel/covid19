sap.ui.define([
	"sap/ui/core/mvc/Controller",

], function(Controller,JSONModel) {
	"use strict";

	return Controller.extend("tsl.hrCOVID.controller.App", {


	});
});